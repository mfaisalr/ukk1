<?php

use Illuminate\Database\Seeder;
use App\User;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::insert([
            [
                "name"      => "Faisal1",
                "email"     => "faisal1@gmail.com",
                "username"  => "faisal11",
                "password"  => bcrypt("faisal11"),
                "level_id"  => 1,
            ],
            [
                "name"      => "Faisal2",
                "email"     => "faisal2@gmail.com",
                "username"  => "faisal22",
                "password"  => bcrypt("faisal22"),
                "level_id"  => 2,
            ],
            [
                "name"      => "Faisal3",
                "email"     => "faisal3@gmail.com",
                "username"  => "faisal33",
                "password"  => bcrypt("faisal33"),
                "level_id"  => 3,
            ],
            [
                "name"      => "Faisal4",
                "email"     => "faisal4@gmail.com",
                "username"  => "faisal44",
                "password"  => bcrypt("faisal44"),
                "level_id"  => 4,
            ],
            [
                "name"      => "Faisal5",
                "email"     => "faisal5@gmail.com",
                "username"  => "faisal55",
                "password"  => bcrypt("faisal55"),
                "level_id"  => 5,
            ]
        ]);
    }
}
