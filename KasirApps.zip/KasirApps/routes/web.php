<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/administrator', 'AdministratorController@index')->name('administrator')->middleware('administrator');
Route::get('/waiter', 'WaiterController@index')->name('waiter')->middleware('waiter');
Route::get('/kasir', 'KasirController@index')->name('kasir')->middleware('kasir');
Route::get('/pelanggan', 'PelangganController@index')->name('pelanggan')->middleware('pelanggan');
Route::get('/owner', 'OwnerController@index')->name('owner')->middleware('owner');
