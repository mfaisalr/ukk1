<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = [
        'no_table',
        'date_order',
        'user_id',
        'information',
        'order_status'
    ];

    protected $table = "orders";

    public function user(){
        return $this->belongsTo('App\User');
    }

    public function detailorder(){
        return $this->hasOne('App\DetailOrder');
    }

    public function transaction(){
        return $this->hasOne('App\Transaction');
    }
}
