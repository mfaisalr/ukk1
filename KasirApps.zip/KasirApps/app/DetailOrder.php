<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetailOrder extends Model
{
    protected $fillable = [
        'order_id',
        'food_id',
        'information',
        'status_detail_order'
    ];

    protected $table = "detail_orders";

    public function order(){
        return $this->belongsTo('App\Order');
    }

    public function food(){
        return $this->belongsTo('App\Food');
    }
}
