@extends('layouts.lay-administrator')
@section('body-content')
<div class="row">
    <div class="col-lg-12">
        <div class="card alert">
            <div class="card-header">
                <div class="card-header-right-icon">
                    <ul>
                        <li class="card-close" data-dismiss="alert"><i class="ti-close"></i></li>
                        <li class="doc-link"><a href="#"><i class="ti-link"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="bootstrap-data-table-panel">
                <button type="button" class="btn btn-info btn-flat btn-addon m-b-10 m-l-5"><i class="ti-plus"></i>Add Food</button>
                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Food Name</th>
                            <th>Price</th>
                            <th>Food Status</th>
                            <th>Option</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div><!-- /# card -->
    </div><!-- /# column -->
</div><!-- /# row -->

@endsection
